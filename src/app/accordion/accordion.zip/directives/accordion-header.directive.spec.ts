import { AccordionHeaderDirective } from './accordion-header.directive';

describe('AccordionHeaderDirective', () => {
  it('should create an instance', () => {
    const directive = new AccordionHeaderDirective();
    expect(directive).toBeTruthy();
  });
});
