import { AccordionTitleDirective } from './accordion-title.directive';

describe('AccordionTitleDirective', () => {
  it('should create an instance', () => {
    const directive = new AccordionTitleDirective();
    expect(directive).toBeTruthy();
  });
});
