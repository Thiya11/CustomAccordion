import { AccordionContentDirective } from './accordion-content.directive';

describe('AccordionContentDirective', () => {
  it('should create an instance', () => {
    const directive = new AccordionContentDirective();
    expect(directive).toBeTruthy();
  });
});
