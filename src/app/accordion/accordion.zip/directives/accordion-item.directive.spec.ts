import { AccordionItemDirective } from './accordion-item.directive';

describe('AccordionItemDirective', () => {
  it('should create an instance', () => {
    const directive = new AccordionItemDirective();
    expect(directive).toBeTruthy();
  });
});
